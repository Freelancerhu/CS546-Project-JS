// const sellers= require("./sellers");
const customerData = require("./customers");
const productsData = require("./products");
module.exports = {
    customers: customerData,
    // sellers: sellers,
    products: productsData
}